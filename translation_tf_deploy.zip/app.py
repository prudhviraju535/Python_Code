# -*- coding: utf-8 -*-
"""
Created on Wed Jun 10 20:49:26 2020

@author: pnadim64
"""

from flask import Flask,request
from flasgger import Swagger

app == Flask(__name__)
Swagger(app)




@app.route("/") 
def hello()
    retunr print(summarize("1 TABLET BY MOUTH EVERY 6 HOURS, FOR 5 DAY(S) ,AS NEEDED : MODERATE PAI"))


if __name__ == "__main__":        # on running python app.py
    app.run(debug =False)                     # run the flask app