#!/usr/bin/env python
# coding: utf-8



import numpy as np
import tensorflow as tf
import pickle

print(tf.__version__)


from transformers import get_angles, positional_encoding,create_padding_mask,create_look_ahead_mask
from transformers import scaled_dot_product_attention,loss_function,create_masks,point_wise_feed_forward_network


from Encoder import Encoder
from EncoderLayer import EncoderLayer
from CustomSchedule import CustomSchedule
from Transformer import Transformer
from DecoderLayer import DecoderLayer
from Decoder import Decoder
import MultiHeadAttention

from flask import Flask,request,jsonify
from flasgger import Swagger
import requests

app = Flask(__name__)
Swagger(app)


file = open("document_tokenizer.pkl",'rb')
document_tokenizer = pickle.load(file)
file = open("summary_tokenizer.pkl",'rb')
summary_tokenizer = pickle.load(file)
file = open("encoder_vocab_size.pkl",'rb')
encoder_vocab_size = pickle.load(file)
file = open("decoder_vocab_size.pkl",'rb')
decoder_vocab_size = pickle.load(file)
encoder_maxlen = 174
decoder_maxlen = 159

# hyper-params
num_layers = 4
d_model = 128
dff = 512
num_heads = 8
EPOCHS = 20

learning_rate = CustomSchedule(d_model)

optimizer = tf.keras.optimizers.Adam(learning_rate, beta_1=0.9, beta_2=0.98, epsilon=1e-9)

#train_loss = tf.keras.metrics.Mean(name='train_loss')
# #### Transformer

transformer = Transformer(
    num_layers, 
    d_model, 
    num_heads, 
    dff,
    encoder_vocab_size, 
    decoder_vocab_size, 
    pe_input=encoder_vocab_size, 
    pe_target=decoder_vocab_size,
)




# #### Checkpoints

#%%

checkpoint_path = "checkpoints"

ckpt = tf.train.Checkpoint(transformer=transformer, optimizer=optimizer)

ckpt_manager = tf.train.CheckpointManager(ckpt, checkpoint_path, max_to_keep=5)

if ckpt_manager.latest_checkpoint:
    ckpt.restore(ckpt_manager.latest_checkpoint)
    print ('Latest checkpoint restored!!')

#%%
# type(transformer)

# with open('tf_model.pkl','wb') as model:
#     pickle.dump(transformer,model)

# ### Inference

# #### Predicting one word at a time at the decoder and appending it to the output; then taking the complete sequence as an input to the decoder and repeating until maxlen or stop keyword appears

#%%
def evaluate(input_document):
    input_document = document_tokenizer.texts_to_sequences([input_document])
    input_document = tf.keras.preprocessing.sequence.pad_sequences(input_document, maxlen=encoder_maxlen, padding='post', truncating='post')

    encoder_input = tf.expand_dims(input_document[0], 0)

    decoder_input = [summary_tokenizer.word_index["<go>"]]
    output = tf.expand_dims(decoder_input, 0)
    
    for i in range(decoder_maxlen):
        enc_padding_mask, combined_mask, dec_padding_mask = create_masks(encoder_input, output)

        predictions, attention_weights = transformer(
            encoder_input, 
            output,
            False,
            enc_padding_mask,
            combined_mask,
            dec_padding_mask
        )

        predictions = predictions[: ,-1:, :]
        predicted_id = tf.cast(tf.argmax(predictions, axis=-1), tf.int32)

        if predicted_id == summary_tokenizer.word_index["<stop>"]:
            return tf.squeeze(output, axis=0), attention_weights

        output = tf.concat([output, predicted_id], axis=-1)

    return tf.squeeze(output, axis=0), attention_weights
#%%
@app.route("/")
def frontpage():
    return "its working"


@app.route('/predict/<string:input_document>',methods = ['GET'])
def summarize(input_document):
    
    """
    Testing Swagger
    ---
    parameters: 
        -  name: input_document
           in: query
           type: string
           required: true
    reponses:
        500:
            bad response
        200:
            translation is 
    """
    #response  = requests.get('http://127.0.0.1:5000/predict')
    #input_document = response.json()['args']['GET']
    input_document = request.args.get('input_document','TAKE 1 TABLEt 2 TIMES')
    # not considering attention weights for now, can be used to plot attention heatmaps in the future
    summarized = evaluate(input_document=input_document)[0].numpy()
    summarized = np.expand_dims(summarized[1:], 0)  # not printing <go> token
    print('working')
    return "output is : "+ str(summary_tokenizer.sequences_to_texts(summarized)[0]), 200 # since there is just one translated document
    


#print(summarize("1 TABLET BY MOUTH EVERY 6 HOURS, FOR 5 DAY(S) ,AS NEEDED : MODERATE PAI"))

if __name__ == "__main__":
    app.run(debug = True)



