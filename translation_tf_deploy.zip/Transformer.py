# -*- coding: utf-8 -*-
"""
Created on Wed Jun 10 17:23:47 2020

@author: pnadim64
"""

import tensorflow as tf
import numpy as np
import pandas as pd
from tqdm import tqdm


from transformers import get_angles, positional_encoding,create_padding_mask,create_look_ahead_mask
from transformers import scaled_dot_product_attention,loss_function,create_masks,point_wise_feed_forward_network

from Encoder import Encoder
from Decoder import Decoder

 #### Finally, the Transformer
class Transformer(tf.keras.Model):
    def __init__(self, num_layers, d_model, num_heads, dff, input_vocab_size, target_vocab_size, pe_input, pe_target, rate=0.1):
        super(Transformer, self).__init__()

        self.encoder = Encoder(num_layers, d_model, num_heads, dff, input_vocab_size, pe_input, rate)

        self.decoder = Decoder(num_layers, d_model, num_heads, dff, target_vocab_size, pe_target, rate)

        self.final_layer = tf.keras.layers.Dense(target_vocab_size)
    
    def __call__(self, inp, tar, training, enc_padding_mask, look_ahead_mask, dec_padding_mask):
        enc_output = self.encoder(inp, training, enc_padding_mask)

        dec_output, attention_weights = self.decoder(tar, enc_output, training, look_ahead_mask, dec_padding_mask)

        final_output = self.final_layer(dec_output)

        return final_output, attention_weights
