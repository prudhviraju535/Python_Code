# -*- coding: utf-8 -*-
"""
Created on Wed Jun 10 17:24:23 2020

@author: pnadim64
"""

import tensorflow as tf
import numpy as np
import pandas as pd
from tqdm import tqdm


from transformers import get_angles, positional_encoding,create_padding_mask,create_look_ahead_mask
from transformers import scaled_dot_product_attention,loss_function,create_masks,point_wise_feed_forward_network


# #### Adam optimizer with custom learning rate scheduling
class CustomSchedule(tf.keras.optimizers.schedules.LearningRateSchedule):
    def __init__(self, d_model, warmup_steps=4000):
        super(CustomSchedule, self).__init__()

        self.d_model = d_model
        self.d_model = tf.cast(self.d_model, tf.float32)

        self.warmup_steps = warmup_steps
    
    def __call__(self, step):
        arg1 = tf.math.rsqrt(step)
        arg2 = step * (self.warmup_steps ** -1.5)

        return tf.math.rsqrt(self.d_model) * tf.math.minimum(arg1, arg2)