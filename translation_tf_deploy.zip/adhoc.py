# -*- coding: utf-8 -*-
"""
Created on Thu Jun 11 13:19:03 2020

@author: pnadim64
"""


# @tf.function
# def train_step(inp, tar):
#     tar_inp = tar[:, :-1]
#     tar_real = tar[:, 1:]

#     enc_padding_mask, combined_mask, dec_padding_mask = create_masks(inp, tar_inp)

#     with tf.GradientTape() as tape:
#         predictions, _ = transformer(
#             inp, tar_inp, 
#             True, 
#             enc_padding_mask, 
#             combined_mask, 
#             dec_padding_mask
#         )
#         loss = loss_function(tar_real, predictions)

#     gradients = tape.gradient(loss, transformer.trainable_variables)    
#     optimizer.apply_gradients(zip(gradients, transformer.trainable_variables))

    #train_loss(loss)
