# -*- coding: utf-8 -*-
"""
Created on Wed Jun 10 17:17:58 2020

@author: pnadim64
"""

import tensorflow as tf
import numpy as np
import pandas as pd
from tqdm import tqdm


from transformers import get_angles, positional_encoding,create_padding_mask,create_look_ahead_mask
from transformers import scaled_dot_product_attention,loss_function,create_masks,point_wise_feed_forward_network


from EncoderLayer import EncoderLayer
# #### Encoder consisting of multiple EncoderLayer(s)

class Encoder(tf.keras.layers.Layer):
    def __init__(self, num_layers, d_model, num_heads, dff, input_vocab_size, maximum_position_encoding, rate=0.1):
        super(Encoder, self).__init__()

        self.d_model = d_model
        self.num_layers = num_layers

        self.embedding = tf.keras.layers.Embedding(input_vocab_size, d_model)
        self.pos_encoding = positional_encoding(maximum_position_encoding, self.d_model)

        self.enc_layers = [EncoderLayer(d_model, num_heads, dff, rate) for _ in tqdm(range(num_layers))]

        self.dropout = tf.keras.layers.Dropout(rate)
        
    def __call__(self, x, training, mask):
        seq_len = tf.shape(x)[1]

        x = self.embedding(x)
        x *= tf.math.sqrt(tf.cast(self.d_model, tf.float32))
        x += self.pos_encoding[:, :seq_len, :]

        x = self.dropout(x, training=training)
    
        for i in range(self.num_layers):
            x = self.enc_layers[i](x, training, mask)
    
        return x